rbac data location.
