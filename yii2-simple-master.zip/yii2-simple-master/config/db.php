<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yii2simple',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
